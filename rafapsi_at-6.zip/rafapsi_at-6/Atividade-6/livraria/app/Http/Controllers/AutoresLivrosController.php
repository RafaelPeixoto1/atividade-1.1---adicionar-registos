<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AutorLivro;


class AutoresLivrosController extends Controller
{
     


}
}

