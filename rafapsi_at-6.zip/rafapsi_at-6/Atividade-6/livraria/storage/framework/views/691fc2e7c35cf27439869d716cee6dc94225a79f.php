ID:<?php echo e($livro->id_livro); ?><br>
Título:<?php echo e($livro->titulo); ?><br>
Idioma:<?php echo e($livro->idioma); ?>


<?php if(isset($livro->genero->designacao)): ?>
<?php echo e($livro->genero->designacao); ?>

<?php endif; ?>

<?php if(count($livro->autores)>0): ?>


<?php $__currentLoopData = $livro->autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($autor->nome); ?><br>
@endeforeach

<?php else: ?>
<div class="alert alert-danger" role="alert">Sem autor definido </div>
<?php endif; ?><?php /**PATH C:\Users\Admin\Desktop\PSI-Atividade-5-main\Atividade-5\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>